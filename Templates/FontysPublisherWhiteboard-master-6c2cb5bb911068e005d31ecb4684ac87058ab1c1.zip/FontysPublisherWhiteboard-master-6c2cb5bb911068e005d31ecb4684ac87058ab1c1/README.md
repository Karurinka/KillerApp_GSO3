README
Example of distributed application using remote FontysPublisher
